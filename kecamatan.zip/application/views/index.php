<?php
// diam itu emas
?>