<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy;  <?php echo date("Y") ?> Desa Babakan Kecamatan tenjo | Made with <span i class="fa fa-heart" style="color:#DC3545"> </span> by Universitas Pamulang </a>
  </footer>